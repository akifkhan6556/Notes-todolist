package bitcode.notes.app.Constant;

import java.io.Serializable;

public class Constant implements Serializable {
    private static final long serialVersionUID = 1L;

    public static String company = "Bitcode";
    public static String email = "bitcodesoftware01@gmail.com";
    public static String website = "https://www.bitcodesoftware.com/";
    public static String contact = "+92 3453119085";
    public static String privacyPolicy = "https://bitcodesoftware.com/privacy/360notesprivacy.html";

    //--------------------Admob ads----------------- //
    public static Boolean isAdmobBannerAd = false;
    public static Boolean  isAdmobInterAd = false;
    public static int adShow = 5;

    //--------------------Fb ads----------------- //
    public static Boolean isFBBannerAd = true;
    public static Boolean  isFBInterAd = true;
    public static int adShowFB = 5;


}