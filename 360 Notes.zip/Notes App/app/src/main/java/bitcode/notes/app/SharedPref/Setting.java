package bitcode.notes.app.SharedPref;

import java.io.Serializable;

public class Setting implements Serializable {

    public static boolean Dark_Mode = true;
    public static Boolean in_code = false;
    public static int adCount = 0;
}