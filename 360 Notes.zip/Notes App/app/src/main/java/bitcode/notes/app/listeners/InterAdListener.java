package bitcode.notes.app.listeners;

import bitcode.notes.app.entities.Note;

public interface InterAdListener {
    void onClick(int position, Note note, String type);
}
