package bitcode.notes.app.view.pflockscreen.views;

import android.content.Context;
import android.util.AttributeSet;

import androidx.appcompat.widget.AppCompatTextView;

public class PFKeyButton extends AppCompatTextView {

    public PFKeyButton(Context context, AttributeSet attrs) {

        super(context, attrs);
    }

    public PFKeyButton(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }



}
