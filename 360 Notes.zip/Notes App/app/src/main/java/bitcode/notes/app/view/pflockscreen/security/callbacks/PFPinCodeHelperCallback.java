package bitcode.notes.app.view.pflockscreen.security.callbacks;

import bitcode.notes.app.view.pflockscreen.security.PFResult;

public interface PFPinCodeHelperCallback<T> {
    void onResult(PFResult<T> result);
}
