package bitcode.notes.app.view.pflockscreen.fragments;

/**
 * Created by aleksandr on 2018/02/14.
 */

public interface PFFingerprintAuthListener {

    void onAuthenticated();

    void onError();
}
